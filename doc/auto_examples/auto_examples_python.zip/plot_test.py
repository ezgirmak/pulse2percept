"""
============================================================================
This is just a test example to get the gallery to compile
============================================================================

This is an example script for the gallery.
"""

import numpy as np
import matplotlib.pyplot as plt


a = np.arange(10)
plt.plot(a)
plt.xlabel('x')
plt.show()
